// Wait for DOM to fully load
document.addEventListener('DOMContentLoaded', function () {
    // Get references to DOM elements
    const showNotificationBtn = document.getElementById('showNotification');
    const notificationContainer = document.getElementById('notificationContainer');

    // Counter to create unique IDs for each notification
    let notificationCounter = 0;

    // Add event listener to the show notification button
    showNotificationBtn.addEventListener('click', function () {
        createNotification();
    });

    /**
     * Creates a new notification and adds it to the notification container
     */
    function createNotification() {
        // Increment counter for unique ID
        notificationCounter++;

        // Create notification element
        const notification = document.createElement('div');
        notification.id = `notification-${notificationCounter}`;
        notification.className = 'bg-blue-50 border-l-4 border-blue-500 p-4 rounded shadow-md relative opacity-0 transform translate-y-3 transition-all duration-300';

        // Add notification content
        notification.innerHTML = `
                    <div class="flex justify-between items-start">
                        <div class="flex-1">
                            <p class="text-blue-700 font-medium">You have a new message!</p>
                            <p class="text-sm text-gray-600 mt-1">Notification #${notificationCounter}</p>
                        </div>
                        <button class="close-btn text-gray-400 hover:text-gray-600 transition-colors duration-200 ml-2">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                            </svg>
                        </button>
                    </div>
                `;

        // Insert the notification at the top of the container
        if (notificationContainer.firstChild) {
            notificationContainer.insertBefore(notification, notificationContainer.firstChild);
        } else {
            notificationContainer.appendChild(notification);
        }

        // Add click event to close button using event delegation
        notification.querySelector('.close-btn').addEventListener('click', function () {
            removeNotification(notification);
        });

        // Trigger animation to show the notification (after a small delay for the DOM to update)
        setTimeout(() => {
            notification.classList.remove('opacity-0', 'translate-y-3');
        }, 10);

        // Set auto-dismiss timer (5 seconds)
        const timerId = setTimeout(() => {
            removeNotification(notification);
        }, 5000);

        // Store timer ID on the notification element for cleanup if manually closed
        notification.dataset.timerId = timerId;
    }

    /**
     * Removes a notification with a fade-out animation
     * @param {HTMLElement} notification - The notification element to remove
     */
    function removeNotification(notification) {
        // Cancel the auto-dismiss timer if it exists
        if (notification.dataset.timerId) {
            clearTimeout(parseInt(notification.dataset.timerId));
        }

        // Add animation classes for fade out
        notification.classList.add('opacity-0', 'translate-y-3');

        // Remove the element after animation completes
        setTimeout(() => {
            notification.remove();
        }, 300); // Match the duration in the transition class
    }
});